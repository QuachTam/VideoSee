//
//  RWLabel.h
//  DeviantArtBrowser
//
//  Created by eagle on 14/8/16.
//  Copyright (c) 2014年 Razeware, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RWLabel : UILabel

@end
