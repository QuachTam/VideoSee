//
//  PhotoModel.m
//  StoreManager
//
//  Created by ATam on 12/21/15.
//  Copyright (c) 2015 ATam. All rights reserved.
//

#import "PhotoModel.h"

@implementation PhotoModel

@end
