//
//  TextRLModel.m
//  StoreManager
//
//  Created by ATam on 12/22/15.
//  Copyright (c) 2015 ATam. All rights reserved.
//

#import "TextRLModel.h"

@implementation TextRLModel

@end
