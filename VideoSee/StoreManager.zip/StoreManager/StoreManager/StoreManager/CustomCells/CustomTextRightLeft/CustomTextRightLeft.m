//
//  CustomTextRightLeft.m
//  StoreManager
//
//  Created by ATam on 12/22/15.
//  Copyright (c) 2015 ATam. All rights reserved.
//

#import "CustomTextRightLeft.h"

@implementation CustomTextRightLeft

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
