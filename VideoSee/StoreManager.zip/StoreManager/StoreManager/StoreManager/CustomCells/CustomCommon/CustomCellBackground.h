//
//  CustomCellBackground.h
//  CoolTable
//
//  Created by Brian Moakley on 2/17/13.
//  Copyright (c) 2013 Razeware. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomCellBackground : UIView

@property (nonatomic, assign) BOOL lastCell;
@property (nonatomic, assign) BOOL selected;

@end
