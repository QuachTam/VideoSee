//
//  CustomFooter.h
//  CoolTable
//
//  Created by Brian Moakley on 2/21/13.
//  Copyright (c) 2013 Razeware. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomFooter : UIView

@end
